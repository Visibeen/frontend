import * as React from "react";
const Component = props => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 18" {...props}><path xmlns="http://www.w3.org/2000/svg" fill="currentColor" d="M7 0 6 3H2l1 4-3 2 3 2-1 4h4l1 3 3-2 3 2 1-3h4l-1-4 3-2-3-2 1-4h-4l-1-3-3 2zm7 5 1 1-7 7-3-3 1-1 2 2z" /></svg>;
export default Component;