import * as React from "react";
const Component = props => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 15 16.667" {...props}><path xmlns="http://www.w3.org/2000/svg" fill="currentColor" d="M0 16.667V5h3.333v11.667zm5.833 0V0h3.334v16.667zm5.834 0V10H15v6.667z" /></svg>;
export default Component;