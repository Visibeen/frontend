// No dynamic mock data required for login form - all content is static UI text

// Data passed as props to the root component
export const mockRootProps = {
  // No external props needed - component manages its own state
};