import * as React from "react";
const Component = props => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 15.333" {...props}><path xmlns="http://www.w3.org/2000/svg" stroke="#121927" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M1 4.333 4.33 1m0 0 3.34 3.333M4.33 1v7.5m5 2.5 3.34 3.333m0 0L16 11m-3.33 3.333V6" /></svg>;
export default Component;