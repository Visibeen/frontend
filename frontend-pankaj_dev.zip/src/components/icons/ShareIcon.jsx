import * as React from "react";
const Component = props => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 15.167 15.167" {...props}><path xmlns="http://www.w3.org/2000/svg" stroke="#121927" strokeLinecap="round" strokeLinejoin="round" d="M14.667.5.5 5.083l5.417 2.5 5.833-4.166L7.583 9.25l2.5 5.417z" /></svg>;
export default Component;